<?php

return array(
	'Art & Design'           => esc_html_x( 'Art & Design', 'Layout Category', 'et_builder' ),
	'Business'               => esc_html_x( 'Business', 'Layout Category', 'et_builder' ),
	'Community & Non-Profit' => esc_html_x( 'Community & Non-Profit', 'Layout Category', 'et_builder' ),
	'Education'              => esc_html_x( 'Education', 'Layout Category', 'et_builder' ),
	'Events'                 => esc_html_x( 'Events', 'Layout Category', 'et_builder' ),
	'Fashion & Beauty'       => esc_html_x( 'Fashion & Beauty', 'Layout Category', 'et_builder' ),
	'Food & Drink'           => esc_html_x( 'Food & Drink', 'Layout Category', 'et_builder' ),
	'Health & Fitness'       => esc_html_x( 'Health & Fitness', 'Layout Category', 'et_builder' ),
	'Online Store'           => esc_html_x( 'Online Store', 'Layout Category', 'et_builder' ),
	'Services'               => esc_html_x( 'Services', 'Layout Category', 'et_builder' ),
	'Technology'             => esc_html_x( 'Technology', 'Layout Category', 'et_builder' ),
);
